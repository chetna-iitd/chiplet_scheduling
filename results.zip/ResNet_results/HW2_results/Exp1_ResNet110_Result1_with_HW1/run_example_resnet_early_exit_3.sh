./maestro --HW_file='data/hw/accelerator_1.m' \
          --Mapping_file='data/mapping/resnet110x3_model_map.m' \
          --print_res=true \
          --print_res_csv_file=true \
          --print_log_file=false \
