num_pes: 64
l1_size_cstr: 10000
l2_size_cstr: 300000
noc_bw_cstr: 10
offchip_bw_cstr: 10
